import React, { createContext, useContext, useState, useEffect } from 'react';

export type ThemeName = 'cobalt' | 'cyan' | 'emerald' | 'purple' | 'crimson';

export interface ThemeColors {
  id: ThemeName;
  name: string;
  badge: string;
  primary: string; // e.g. #2563EB
  primaryHover: string;
  secondary: string; // e.g. #38BDF8
  accentGlow: string; // rgba(37, 99, 235, 0.3)
  canvas: string; // background
  surface: string; // cards
  surfaceLight: string; // inner inputs
  border: string; // card borders
  textMuted: string;
}

export const themes: Record<ThemeName, ThemeColors> = {
  cobalt: {
    id: 'cobalt',
    name: 'Cobalt Blue (Template)',
    badge: '⚡ COBALT',
    primary: '#2563EB',
    primaryHover: '#1D4ED8',
    secondary: '#38BDF8',
    accentGlow: 'rgba(37, 99, 235, 0.35)',
    canvas: '#060814',
    surface: '#0B1024',
    surfaceLight: '#0E1738',
    border: '#1A2748',
    textMuted: '#94A3B8',
  },
  cyan: {
    id: 'cyan',
    name: 'Cyber Cyan',
    badge: '❄️ CYAN',
    primary: '#0891B2',
    primaryHover: '#0E7490',
    secondary: '#22D3EE',
    accentGlow: 'rgba(6, 182, 212, 0.35)',
    canvas: '#040912',
    surface: '#091626',
    surfaceLight: '#0E2138',
    border: '#14314E',
    textMuted: '#94A3B8',
  },
  emerald: {
    id: 'emerald',
    name: 'Matrix Emerald',
    badge: '🛡️ EMERALD',
    primary: '#059669',
    primaryHover: '#047857',
    secondary: '#34D399',
    accentGlow: 'rgba(16, 185, 129, 0.35)',
    canvas: '#040B07',
    surface: '#091A11',
    surfaceLight: '#0E2619',
    border: '#153A26',
    textMuted: '#94A3B8',
  },
  purple: {
    id: 'purple',
    name: 'Neon Violet',
    badge: '🔮 VIOLET',
    primary: '#7C3AED',
    primaryHover: '#6D28D9',
    secondary: '#A78BFA',
    accentGlow: 'rgba(124, 58, 237, 0.35)',
    canvas: '#090716',
    surface: '#130F2A',
    surfaceLight: '#1B153C',
    border: '#29204E',
    textMuted: '#A9A5BD',
  },
  crimson: {
    id: 'crimson',
    name: 'Red Team Ops',
    badge: '🚨 RED TEAM',
    primary: '#DC2626',
    primaryHover: '#B91C1C',
    secondary: '#F87171',
    accentGlow: 'rgba(220, 38, 38, 0.35)',
    canvas: '#0C0507',
    surface: '#1A0B10',
    surfaceLight: '#261117',
    border: '#3B1822',
    textMuted: '#94A3B8',
  },
};

interface ThemeContextType {
  themeName: ThemeName;
  theme: ThemeColors;
  setThemeName: (t: ThemeName) => void;
}

const ThemeContext = createContext<ThemeContextType>({
  themeName: 'cobalt',
  theme: themes.cobalt,
  setThemeName: () => {},
});

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [themeName, setThemeName] = useState<ThemeName>('cobalt');

  useEffect(() => {
    const saved = localStorage.getItem('app_theme') as ThemeName;
    if (saved && themes[saved]) {
      setThemeName(saved);
    }
  }, []);

  const handleSetTheme = (t: ThemeName) => {
    setThemeName(t);
    localStorage.setItem('app_theme', t);
  };

  const theme = themes[themeName] || themes.cobalt;

  return (
    <ThemeContext.Provider value={{ themeName, theme, setThemeName: handleSetTheme }}>
      <div
        style={
          {
            '--theme-primary': theme.primary,
            '--theme-primary-hover': theme.primaryHover,
            '--theme-secondary': theme.secondary,
            '--theme-glow': theme.accentGlow,
            '--theme-canvas': theme.canvas,
            '--theme-surface': theme.surface,
            '--theme-surface-light': theme.surfaceLight,
            '--theme-border': theme.border,
          } as React.CSSProperties
        }
      >
        {children}
      </div>
    </ThemeContext.Provider>
  );
};

export const useTheme = () => useContext(ThemeContext);
