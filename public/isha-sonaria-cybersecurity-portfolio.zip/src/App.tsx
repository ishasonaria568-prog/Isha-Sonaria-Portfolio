import React, { useState, useEffect } from 'react';
import { ThemeProvider } from './context/ThemeContext';
import { Header, TabId } from './components/Header';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { SkillsSection } from './components/SkillsSection';
import { ProjectsSection } from './components/ProjectsSection';
import { GitHubSection } from './components/GitHubSection';
import { ExperienceSection } from './components/ExperienceSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { ResumeModal } from './components/ResumeModal';
import { InteractiveTerminalModal } from './components/InteractiveTerminalModal';
import { GitHubDeployModal } from './components/GitHubDeployModal';

const SECTIONS: { id: string; tab: TabId; label: string }[] = [
  { id: 'overview', tab: 'overview', label: 'Overview' },
  { id: 'about', tab: 'about', label: 'About' },
  { id: 'stack', tab: 'stack', label: 'Stack' },
  { id: 'projects', tab: 'projects', label: 'Projects' },
  { id: 'github', tab: 'github', label: 'GitHub' },
  { id: 'experience', tab: 'experience', label: 'Experience' },
  { id: 'contact', tab: 'contact', label: 'Contact' },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>('overview');
  const [isResumeOpen, setIsResumeOpen] = useState(false);
  const [isTerminalOpen, setIsTerminalOpen] = useState(false);
  const [isGitHubModalOpen, setIsGitHubModalOpen] = useState(false);

  // Smooth scroll handler
  const handleSelectTab = (tab: TabId) => {
    setActiveTab(tab);
    if (tab === 'overview') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    const element = document.getElementById(tab);
    if (element) {
      const navOffset = 70;
      const elementPosition = element.getBoundingClientRect().top + window.pageYOffset;
      window.scrollTo({
        top: Math.max(0, elementPosition - navOffset),
        behavior: 'smooth',
      });
    }
  };

  // Scroll Spy to highlight active section in navbar as user scrolls
  useEffect(() => {
    const handleScroll = () => {
      const scrollPos = window.scrollY + 140;
      for (let i = SECTIONS.length - 1; i >= 0; i--) {
        const sec = document.getElementById(SECTIONS[i].id);
        if (sec && scrollPos >= sec.offsetTop) {
          setActiveTab(SECTIONS[i].tab);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <ThemeProvider>
      <div className="min-h-screen bg-[#060A12] text-[#94A3B8] font-sans selection:bg-[#22D3EE]/30 selection:text-white relative overflow-x-hidden">
        {/* Ambient Top Glow */}
        <div className="fixed top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[300px] bg-gradient-to-b from-[#0284C7]/15 to-transparent blur-[140px] pointer-events-none z-0" />

        {/* Header Navigation */}
        <Header
          activeTab={activeTab}
          onSelectTab={handleSelectTab}
          onOpenResume={() => setIsResumeOpen(true)}
          onOpenTerminal={() => setIsTerminalOpen(true)}
        />

        {/* Main Content Area */}
        <main className="relative z-10 pt-16 sm:pt-20">
          <Hero
            onSelectTab={handleSelectTab}
            onOpenResume={() => setIsResumeOpen(true)}
            onOpenTerminal={() => setIsTerminalOpen(true)}
          />
          <AboutSection onSelectTab={handleSelectTab} />
          <SkillsSection onSelectTab={handleSelectTab} />
          <ProjectsSection onSelectTab={handleSelectTab} />
          <GitHubSection onSelectTab={handleSelectTab} />
          <ExperienceSection onSelectTab={handleSelectTab} />
          <ContactSection onSelectTab={handleSelectTab} />
          <Footer onSelectTab={handleSelectTab} />
        </main>

        {/* Modals */}
        <ResumeModal
          isOpen={isResumeOpen}
          onClose={() => setIsResumeOpen(false)}
        />

        <InteractiveTerminalModal
          isOpen={isTerminalOpen}
          onClose={() => setIsTerminalOpen(false)}
        />

        <GitHubDeployModal
          isOpen={isGitHubModalOpen}
          onClose={() => setIsGitHubModalOpen(false)}
        />
      </div>
    </ThemeProvider>
  );
}
