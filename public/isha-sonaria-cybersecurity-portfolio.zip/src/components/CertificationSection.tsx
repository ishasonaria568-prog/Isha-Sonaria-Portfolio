import React, { useState } from 'react';
import { certificationData, educationData } from '../data/portfolioData';
import { TabId } from './Header';
import {
  Award,
  ExternalLink,
  CheckCircle2,
  BookOpen,
  GraduationCap,
  ShieldCheck,
  MapPin,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Zap,
} from 'lucide-react';

interface CertificationSectionProps {
  onSelectTab?: (tab: TabId) => void;
}

export const CertificationSection: React.FC<CertificationSectionProps> = ({ onSelectTab }) => {
  const [verifying, setVerifying] = useState(false);
  const [verifiedState, setVerifiedState] = useState(false);

  const handleSimulateVerification = () => {
    setVerifying(true);
    setTimeout(() => {
      setVerifying(false);
      setVerifiedState(true);
    }, 1000);
  };

  return (
    <section id="credentials" className="py-16 md:py-24 relative border-b border-[#16335C]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 pb-5 border-b border-[#16335C] gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-[#38BDF8] mb-2 font-semibold">
              <Award className="w-4 h-4" />
              <span>OFFICIAL_CREDENTIALS // ACADEMIC_RECORD // VERIFIED</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold font-mono text-white uppercase tracking-tight">
              CERTIFICATION &amp; EDUCATION
            </h2>
            <p className="text-sm text-[#94A3B8] mt-1 max-w-2xl font-sans">
              Verified industry foundations, platform credentials, and formal computer science undergraduate degree.
            </p>
          </div>

          <div className="font-mono text-xs text-[#7DD3FC] flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#0B172E] border border-[#16335C]">
            <span className="w-2 h-2 rounded-full bg-[#34D399] animate-pulse" />
            <span>AUTHENTICATED ACCREDITATION</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Hackviser Certification Card with Light-Blue glow */}
          <div className="lg:col-span-7">
            <div className="p-6 sm:p-8 rounded-xl bg-[#0B172E] border border-[#16335C] hover:border-[#38BDF8] transition-all shadow-xl shadow-black/40 relative overflow-hidden group">
              <div className="flex items-center justify-between mb-4">
                <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-[#38BDF8]/20 border border-[#38BDF8]/40 text-[#7DD3FC]">
                  INDUSTRY CERTIFICATION
                </span>
                <span className="text-xs font-mono text-[#34D399] flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-[#34D399]" />
                  <span>VERIFIED ACTIVE</span>
                </span>
              </div>

              <h3 className="text-xl sm:text-2xl font-extrabold font-mono text-white mb-1 group-hover:text-[#38BDF8] transition-colors">
                {certificationData.title}
              </h3>
              <p className="text-sm font-mono text-[#7DD3FC] mb-4">
                ISSUED BY: {certificationData.issuer} • {certificationData.date}
              </p>

              {/* Credential ID and Verification actions */}
              <div className="p-4 rounded-xl bg-[#040814] border border-[#16335C] mb-6 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
                <div>
                  <span className="text-[#94A3B8]">CREDENTIAL ID: </span>
                  <span className="text-white font-bold">{certificationData.credentialId}</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleSimulateVerification}
                    className="px-2.5 py-1 rounded bg-[#0B172E] border border-[#38BDF8]/40 text-[#38BDF8] hover:bg-[#38BDF8]/20 transition-all cursor-pointer"
                  >
                    {verifying ? 'CHECKING...' : verifiedState ? '✓ SIGNATURE VALID' : 'CHECK SIGNATURE'}
                  </button>
                  <a
                    href={certificationData.verificationUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[#7DD3FC] hover:text-white transition-colors"
                  >
                    <span>Verify Link</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              <div className="space-y-3">
                <span className="text-xs font-mono uppercase tracking-wider text-[#7DD3FC] font-semibold block">
                  DEMONSTRATED COMPETENCIES:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {certificationData.competencies.map((comp) => (
                    <div
                      key={comp}
                      className="flex items-start gap-2 p-2.5 rounded-lg bg-[#040814] border border-[#16335C] text-xs font-sans text-white hover:border-[#38BDF8]/40 transition-colors"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#34D399] shrink-0 mt-0.5" />
                      <span>{comp}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Academic Degree Card */}
          <div className="lg:col-span-5">
            <div className="p-6 sm:p-8 rounded-xl bg-[#0B172E] border border-[#16335C] hover:border-[#38BDF8]/60 transition-all shadow-xl shadow-black/40 space-y-5">
              <div className="flex items-center justify-between">
                <span className="px-3 py-1 rounded-full text-xs font-mono font-bold bg-[#38BDF8]/15 border border-[#38BDF8]/30 text-[#38BDF8]">
                  HIGHER EDUCATION
                </span>
                <span className="text-xs font-mono text-[#94A3B8] flex items-center gap-1">
                  <GraduationCap className="w-4 h-4 text-[#38BDF8]" />
                  <span>2023 — 2026</span>
                </span>
              </div>

              <div>
                <h3 className="text-xl font-extrabold font-mono text-white mb-1">
                  {educationData.degree}
                </h3>
                <p className="text-sm font-sans text-[#7DD3FC] mb-2 font-medium">
                  {educationData.institution}
                </p>
                <div className="flex items-center gap-1.5 text-xs text-[#94A3B8] font-mono">
                  <MapPin className="w-3.5 h-3.5 text-[#38BDF8]" />
                  <span>{educationData.location}</span>
                </div>
              </div>

              {/* Performance Badges */}
              <div className="p-4 rounded-xl bg-[#040814] border border-[#16335C] flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
                <div>
                  <span className="text-[#94A3B8]">CURRENT CGPA: </span>
                  <span className="text-[#34D399] font-extrabold text-sm">{educationData.cgpa}</span>
                  <span className="text-[#94A3B8] text-[10px]"> / 10.0</span>
                </div>
                <span className="px-2.5 py-0.5 rounded-full bg-[#38BDF8]/20 border border-[#38BDF8]/40 text-[#7DD3FC] font-bold">
                  {educationData.achievement}
                </span>
              </div>

              <div>
                <span className="text-xs font-mono uppercase tracking-wider text-[#7DD3FC] font-semibold block mb-2">
                  CURRICULUM HIGHLIGHTS:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {educationData.coursework.map((course) => (
                    <span
                      key={course}
                      className="px-2.5 py-1 rounded-lg bg-[#040814] border border-[#16335C] text-xs font-mono text-white"
                    >
                      {course}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
