import React, { useState } from 'react';
import { toolArsenalData } from '../data/portfolioData';
import { Terminal, Copy, Check, Wrench, Shield, Search, Eye } from 'lucide-react';

export const ToolArsenalSection: React.FC = () => {
  const [selectedCategoryName, setSelectedCategoryName] = useState<string>(
    toolArsenalData[0]?.category || 'RECONNAISSANCE'
  );
  const [copiedCommand, setCopiedCommand] = useState<string | null>(null);

  const currentCategory =
    toolArsenalData.find((c) => c.category === selectedCategoryName) || toolArsenalData[0];

  const handleCopyCommand = (cmd: string) => {
    navigator.clipboard.writeText(cmd);
    setCopiedCommand(cmd);
    setTimeout(() => setCopiedCommand(null), 2000);
  };

  return (
    <section id="toolkit" className="py-16 md:py-24 bg-[#060814] border-b border-[#1A2748] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-6 border-b border-[#1A2748] gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-[#38BDF8] mb-2">
              <Wrench className="w-3.5 h-3.5" />
              <span>PRACTICAL_ARSENAL // FUNCTIONAL_PURPOSE</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold font-mono text-white uppercase tracking-tight">
              SECURITY TOOLKIT
            </h2>
            <p className="text-sm text-[#94A3B8] mt-1 max-w-2xl font-sans">
              Direct CLI utilities, network listeners, and forensic frameworks leveraged in daily security labs.
            </p>
          </div>

          <div className="font-mono text-xs text-[#94A3B8] flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#34D399]" />
            <span>OPERATIONAL UTILITIES</span>
          </div>
        </div>

        {/* Category Selector Tabs */}
        <div className="flex flex-wrap gap-2 mb-8">
          {toolArsenalData.map((cat) => {
            const isSelected = cat.category === selectedCategoryName;
            return (
              <button
                key={cat.category}
                onClick={() => setSelectedCategoryName(cat.category)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-mono font-medium tracking-wider transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-[#2563EB] text-white shadow-md shadow-[#8B5CF6]/30 border border-[#A78BFA]'
                    : 'bg-[#0B1024] text-[#94A3B8] hover:text-white hover:bg-[#1f1d38] border border-[#1A2748]'
                }`}
              >
                {cat.category}
              </button>
            );
          })}
        </div>

        {/* Category Description Banner */}
        <div className="p-4 rounded-xl bg-[#0B1024] border border-[#1A2748] mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono font-bold text-[#38BDF8] uppercase tracking-wider">
              CATEGORY OBJECTIVE:
            </span>
            <span className="text-xs sm:text-sm text-white font-sans">
              {currentCategory.purpose}
            </span>
          </div>
          <span className="text-[11px] font-mono text-[#94A3B8] shrink-0">
            {currentCategory.tools.length} TOOLS IN SUITE
          </span>
        </div>

        {/* Tools Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {currentCategory.tools.map((tool) => (
            <div
              key={tool.name}
              className="p-5 rounded-xl bg-[#0B1024] border border-[#1A2748] hover:border-[#22D3EE]/40 transition-all flex flex-col justify-between group shadow-lg"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-base font-bold font-mono text-white group-hover:text-[#38BDF8] transition-colors">
                    {tool.name}
                  </h3>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#080D1D] text-blue-400 border border-[#1A2748]">
                    PRACTICAL ROLE
                  </span>
                </div>

                <p className="text-xs text-[#94A3B8] font-sans leading-relaxed mb-4">
                  {tool.practicalRole}
                </p>
              </div>

              {/* Typical Command Snippet */}
              <div className="pt-3 border-t border-[#1A2748]">
                <div className="flex items-center justify-between mb-1.5 text-[10px] font-mono text-[#94A3B8]">
                  <span>STANDARD SYNTAX:</span>
                  <button
                    onClick={() => handleCopyCommand(tool.typicalCommand)}
                    className="text-[#38BDF8] hover:text-blue-400 flex items-center gap-1 cursor-pointer transition-colors"
                    title="Copy command"
                  >
                    {copiedCommand === tool.typicalCommand ? (
                      <>
                        <Check className="w-3 h-3 text-[#34D399]" />
                        <span className="text-[#34D399]">COPIED</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>COPY</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="p-2.5 rounded bg-[#060814] border border-[#1A2748] font-mono text-[11px] text-[#34D399] break-all select-all flex items-center justify-between">
                  <span>{tool.typicalCommand}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
