import React, { useState } from 'react';
import { projectsData, ProjectItem } from '../data/portfolioData';
import { TabId } from './Header';
import {
  ExternalLink,
  Github,
  Play,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Terminal,
  Shield,
  Layers,
  Sparkles,
} from 'lucide-react';

interface ProjectsSectionProps {
  onSelectTab?: (tab: TabId) => void;
}

export const ProjectsSection: React.FC<ProjectsSectionProps> = () => {
  const [selectedFilter, setSelectedFilter] = useState('ALL');
  const [subscopeRunning, setSubscopeRunning] = useState(false);
  const [subscopeLogs, setSubscopeLogs] = useState<string[]>([]);

  const filterCategories = [
    { label: 'All (5)', value: 'ALL' },
    { label: 'Machine Learning', value: 'Machine Learning' },
    { label: 'Digital Forensics', value: 'Forensics' },
    { label: 'Reconnaissance', value: 'Reconnaissance' },
    { label: 'Secure Web', value: 'Secure Web' },
  ];

  const filteredProjects = projectsData.filter((project) => {
    if (selectedFilter === 'ALL') return true;
    return project.category.toLowerCase().includes(selectedFilter.toLowerCase());
  });

  const handleRunSubscope = () => {
    setSubscopeRunning(true);
    setSubscopeLogs(['[INIT] SubScope v1.2 concurrent resolver starting...']);

    const steps = [
      '[DNS] Resolving target: enterprise-network.lab (threads: 16)',
      '[+] [HTTP 200] api.enterprise-network.lab -> 104.21.32.18',
      '[!] [HTTP 404] dev.enterprise-network.lab -> CNAME s3.aws.com [TAKEOVER RISK]',
      '[+] [HTTP 403] admin-portal.enterprise-network.lab -> Internal IP',
      '[DONE] Scanned 2,400 permutations: 3 live hosts identified | JSON exported',
    ];

    steps.forEach((log, index) => {
      setTimeout(() => {
        setSubscopeLogs((prev) => [...prev, log]);
        if (index === steps.length - 1) {
          setSubscopeRunning(false);
        }
      }, (index + 1) * 400);
    });
  };

  return (
    <section id="projects" className="py-14 md:py-20 border-t border-[#1A2642] relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Section Header with Category Filters (Matching video 00:02) */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-[#22D3EE] font-semibold mb-3">
              <span>• 03 // FEATURED WORK</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight">
              Flagship Security Projects
            </h2>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-2">
            {filterCategories.map((f) => (
              <button
                key={f.value}
                onClick={() => setSelectedFilter(f.value)}
                className={`px-3 py-1.5 rounded-full text-xs font-mono transition-all cursor-pointer ${
                  selectedFilter === f.value
                    ? 'bg-gradient-to-r from-[#22D3EE] to-[#38BDF8] text-[#060A12] font-bold shadow-md shadow-[#22D3EE]/25'
                    : 'bg-[#0D1527] border border-[#1E2D4A] text-[#94A3B8] hover:text-white hover:border-[#22D3EE]/40'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* 2-Column Project Cards Grid (Matching video 00:02-00:06) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredProjects.map((project) => (
            <div
              key={project.name}
              className="p-6 rounded-2xl bg-[#0D1527] border border-[#1E2D4A] hover:border-[#22D3EE]/60 transition-all flex flex-col justify-between group shadow-xl shadow-black/40"
            >
              <div>
                {/* Upper Mockup / Telemetry Display Frame (Matching video app mockup container) */}
                <div className="w-full h-44 rounded-xl bg-gradient-to-br from-[#080D1A] to-[#10192D] border border-[#1E2D4A] p-4 mb-5 flex flex-col justify-between relative overflow-hidden group-hover:border-[#22D3EE]/40 transition-colors">
                  {/* Subtle top glare */}
                  <div className="absolute top-0 right-0 w-40 h-40 bg-[#22D3EE]/5 rounded-full blur-2xl pointer-events-none" />

                  {/* Top Bar inside frame */}
                  <div className="flex items-center justify-between z-10">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
                      <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
                    </div>

                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#22D3EE]/15 border border-[#22D3EE]/40 text-[#22D3EE] font-semibold">
                      ✦ {project.category}
                    </span>
                  </div>

                  {/* Center Content / Mini Preview inside frame */}
                  <div className="z-10 my-auto text-left">
                    <div className="text-xs font-mono text-[#22D3EE] font-bold">
                      {project.name}
                    </div>
                    <div className="text-[11px] text-[#94A3B8] font-mono mt-0.5 line-clamp-2">
                      {project.tagline}
                    </div>
                  </div>

                  {/* Frame Footer Pills */}
                  <div className="flex flex-wrap items-center gap-1.5 z-10">
                    {project.features.slice(0, 3).map((feat) => (
                      <span
                        key={feat}
                        className="text-[9px] font-mono px-2 py-0.5 rounded-md bg-[#0D1527] border border-[#1E2D4A] text-[#E0F2FE]"
                      >
                        {feat}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Project Title */}
                <h3 className="text-xl font-bold text-white group-hover:text-[#22D3EE] transition-colors mb-2 text-left">
                  {project.name}
                </h3>

                {/* Description */}
                <p className="text-xs sm:text-sm text-[#94A3B8] leading-relaxed mb-4 text-left line-clamp-3">
                  {project.description}
                </p>

                {/* Technology Pills */}
                <div className="flex flex-wrap gap-1.5 mb-6 text-left">
                  {project.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="text-[11px] font-mono px-2.5 py-1 rounded-lg bg-[#080D1A] border border-[#1E2D4A] text-[#7DD3FC]"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action Buttons at bottom: Live Demo & Source (Matching video) */}
              <div className="flex items-center gap-2.5 pt-4 border-t border-[#1E2D4A]">
                {project.liveUrl ? (
                  <a
                    href={project.liveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 py-2.5 px-4 rounded-xl text-xs font-bold text-[#060A12] bg-gradient-to-r from-[#22D3EE] to-[#38BDF8] hover:brightness-110 shadow-md shadow-[#22D3EE]/25 flex items-center justify-center gap-1.5 transition-all"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Live Demo</span>
                  </a>
                ) : project.name === 'SUBSCOPE' ? (
                  <button
                    onClick={handleRunSubscope}
                    disabled={subscopeRunning}
                    className="flex-1 py-2.5 px-4 rounded-xl text-xs font-bold text-[#060A12] bg-gradient-to-r from-[#22D3EE] to-[#38BDF8] hover:brightness-110 shadow-md shadow-[#22D3EE]/25 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <Terminal className="w-3.5 h-3.5" />
                    <span>{subscopeRunning ? 'Scanning...' : 'Live Scan'}</span>
                  </button>
                ) : null}

                <a
                  href={project.githubUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`${
                    project.liveUrl || project.name === 'SUBSCOPE' ? 'flex-1' : 'w-full'
                  } py-2.5 px-4 rounded-xl text-xs font-semibold text-white bg-[#080D1A] border border-[#1E2D4A] hover:border-[#22D3EE] hover:bg-[#16233B] flex items-center justify-center gap-1.5 transition-all`}
                >
                  <Github className="w-3.5 h-3.5 text-[#22D3EE]" />
                  <span>Source</span>
                </a>
              </div>

              {/* Interactive log output for SubScope scan if running */}
              {project.name === 'SUBSCOPE' && subscopeLogs.length > 0 && (
                <div className="mt-3 p-3 rounded-lg bg-[#060A12] border border-[#1E2D4A] text-[10px] font-mono text-left max-h-28 overflow-y-auto">
                  {subscopeLogs.map((log, i) => (
                    <div
                      key={i}
                      className={
                        log.includes('TAKEOVER')
                          ? 'text-amber-400 font-bold'
                          : log.includes('DONE')
                          ? 'text-[#22D3EE] font-bold'
                          : 'text-[#94A3B8]'
                      }
                    >
                      {log}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
