import React, { useState, useEffect } from 'react';
import { personalProfile, tryHackMeMetrics } from '../data/portfolioData';
import { TabId } from './Header';
import {
  ArrowRight,
  MessageSquare,
  Phone,
  Mail,
  Linkedin,
  Github,
  FileText,
  MapPin,
  Shield,
  Zap,
  Sparkles,
  ExternalLink,
  GraduationCap,
  Award,
} from 'lucide-react';

interface HeroProps {
  onSelectTab: (tab: TabId) => void;
  onOpenResume: () => void;
  onOpenTerminal?: () => void;
}

const ROLES = [
  'Cybersecurity & SOC L1 Analyst',
  'Deep Packet Forensics & Wireshark',
  'TryHackMe Top 2% Global Operator',
  'Python Security Tooling & Defense',
];

export const Hero: React.FC<HeroProps> = ({ onSelectTab, onOpenResume }) => {
  const [roleIndex, setRoleIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setRoleIndex((prev) => (prev + 1) % ROLES.length);
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section id="overview" className="relative pt-8 pb-14 md:pt-14 md:pb-20 text-center">
      {/* Background Ambient Glow */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-[#0284C7]/20 via-[#22D3EE]/15 to-transparent blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 relative z-10 flex flex-col items-center">
        {/* Top Status Pill (Matching video) */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#0D1527] border border-[#1E2D4A] text-[#22D3EE] text-xs font-mono mb-6 shadow-sm shadow-[#22D3EE]/10">
          <span className="w-2 h-2 rounded-full bg-[#34D399] animate-pulse" />
          <span className="font-medium tracking-wide">Available for full-time &amp; SOC roles</span>
        </div>

        {/* Headline Intro */}
        <span className="text-base sm:text-lg font-medium text-[#94A3B8] mb-1">
          Hi, I&apos;m
        </span>
        <h1 className="text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-tight text-white mb-2 font-sans">
          {personalProfile.displayName}
        </h1>

        {/* Animated Typing Role Title */}
        <div className="text-2xl sm:text-3xl md:text-4xl font-bold bg-gradient-to-r from-[#22D3EE] via-[#38BDF8] to-[#0284C7] bg-clip-text text-transparent flex items-center justify-center gap-1 min-h-[44px] mb-4">
          <span>{ROLES[roleIndex]}</span>
          <span className="w-1 h-7 bg-[#22D3EE] inline-block animate-cursor-blink ml-1" />
        </div>

        {/* Location & Craftsmanship Badges (Matching video: Ahmedabad | Cross-Platform Craftsmanship) */}
        <div className="flex flex-wrap items-center justify-center gap-2.5 sm:gap-4 text-xs font-mono text-[#94A3B8] mb-6">
          <span className="flex items-center gap-1.5 px-3 py-1 rounded-md bg-[#0D1527] border border-[#1E2D4A] text-[#E0F2FE]">
            <MapPin className="w-3.5 h-3.5 text-[#22D3EE]" />
            <span>Veraval, Gujarat</span>
          </span>
          <span className="flex items-center gap-1.5 px-3 py-1 rounded-md bg-[#0D1527] border border-[#1E2D4A] text-[#7DD3FC]">
            <Shield className="w-3.5 h-3.5 text-[#22D3EE]" />
            <span>Blue Team &amp; Incident Triage</span>
          </span>
          <span className="flex items-center gap-1.5 px-3 py-1 rounded-md bg-[#0D1527] border border-[#1E2D4A] text-[#34D399]">
            <Zap className="w-3.5 h-3.5 text-[#34D399]" />
            <span>105-Day Streak • Top 2%</span>
          </span>
        </div>

        {/* Bio Paragraph */}
        <p className="text-sm sm:text-base text-[#94A3B8] leading-relaxed max-w-2xl mb-10 font-sans">
          BCA graduate and defensive cybersecurity practitioner with hands-on experience investigating security incidents, dissecting network packets in Wireshark, triage alerts in Wazuh SIEM, and building defensive security tooling. Strong foundation in networking, Linux architectures, and practical threat mitigation.
        </p>

        {/* Circular Avatar Container with Orbiting Tech Pills (Matching video 00:00 & 00:26) */}
        <div className="relative mb-8 mt-2 flex items-center justify-center">
          {/* Circular Frame with Neon Halo */}
          <div className="relative w-44 h-44 sm:w-52 sm:h-52 rounded-full p-1 bg-gradient-to-tr from-[#0284C7] via-[#22D3EE] to-[#818CF8] shadow-[0_0_50px_rgba(34,211,238,0.25)] flex items-center justify-center">
            <div className="w-full h-full rounded-full bg-[#080D1A] flex flex-col items-center justify-center relative overflow-hidden border border-[#1E2D4A]">
              <div className="absolute inset-0 bg-gradient-to-b from-[#0D1527] to-[#060A12] flex items-center justify-center">
                {/* Center Monogram / Portrait Avatar */}
                <div className="flex flex-col items-center justify-center">
                  <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#1E293B] to-[#0A1120] border-2 border-[#22D3EE]/60 flex items-center justify-center shadow-lg shadow-[#22D3EE]/20 mb-2">
                    <span className="font-mono font-black text-2xl text-[#22D3EE] tracking-tight">IS</span>
                  </div>
                  <span className="text-xs font-mono font-bold text-white tracking-wider">
                    ISHΛ SONARIA
                  </span>
                  <span className="text-[10px] font-mono text-[#22D3EE] mt-0.5">
                    SOC DEFENDER
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Orbiting Tech Pills Around Avatar (Matching video: Flutter 3.x, Dart, Firebase, Gemini API) */}
          {/* Top-Left: Wireshark */}
          <div className="absolute -top-3 -left-10 sm:-left-16 px-3 py-1.5 rounded-full bg-[#0D1527] border border-[#22D3EE]/50 text-white text-xs font-mono shadow-lg shadow-black/60 flex items-center gap-1.5 hover:scale-105 transition-transform animate-float">
            <span className="text-[#22D3EE]">✦</span>
            <span>Wireshark</span>
          </div>

          {/* Top-Right: Wazuh SIEM */}
          <div className="absolute -top-3 -right-10 sm:-right-16 px-3 py-1.5 rounded-full bg-[#0D1527] border border-[#22D3EE]/50 text-white text-xs font-mono shadow-lg shadow-black/60 flex items-center gap-1.5 hover:scale-105 transition-transform animate-float" style={{ animationDelay: '1s' }}>
            <span className="text-[#22D3EE]">✦</span>
            <span>Wazuh SIEM</span>
          </div>

          {/* Bottom-Left: Python / Go */}
          <div className="absolute -bottom-2 -left-12 sm:-left-20 px-3 py-1.5 rounded-full bg-[#0D1527] border border-[#22D3EE]/50 text-white text-xs font-mono shadow-lg shadow-black/60 flex items-center gap-1.5 hover:scale-105 transition-transform animate-float" style={{ animationDelay: '1.5s' }}>
            <span className="text-[#22D3EE]">✦</span>
            <span>Python / Go</span>
          </div>

          {/* Bottom-Right: TryHackMe Top 2% */}
          <div className="absolute -bottom-2 -right-12 sm:-right-20 px-3 py-1.5 rounded-full bg-[#0D1527] border border-[#22D3EE]/50 text-white text-xs font-mono shadow-lg shadow-black/60 flex items-center gap-1.5 hover:scale-105 transition-transform animate-float" style={{ animationDelay: '2s' }}>
            <span className="text-[#22D3EE]">✦</span>
            <span>THM Top 2%</span>
          </div>
        </div>

        {/* Action Buttons (Matching video: Explore My Work -> | Contact Me) */}
        <div className="flex flex-wrap items-center justify-center gap-3.5 mb-6">
          <button
            onClick={() => onSelectTab('projects')}
            className="px-6 py-3 rounded-xl text-xs sm:text-sm font-bold text-white bg-gradient-to-r from-[#0284C7] via-[#0EA5E9] to-[#38BDF8] hover:brightness-110 shadow-lg shadow-[#0284C7]/30 transition-all cursor-pointer flex items-center gap-2 active:scale-95 group"
          >
            <span>Explore My Work</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>

          <button
            onClick={() => onSelectTab('contact')}
            className="px-5 py-3 rounded-xl text-xs sm:text-sm font-semibold text-white bg-[#0D1527] border border-[#1E2D4A] hover:border-[#22D3EE] hover:bg-[#16233B] transition-all cursor-pointer flex items-center gap-2 active:scale-95"
          >
            <MessageSquare className="w-4 h-4 text-[#22D3EE]" />
            <span>Contact Me</span>
          </button>
        </div>

        {/* Quick Contact Icon Strip (Matching video: phone, code, link, email, CV.PDF) */}
        <div className="flex items-center gap-2 sm:gap-2.5 p-2 rounded-xl bg-[#0D1527] border border-[#1E2D4A] mb-12 shadow-sm">
          <a
            href="tel:+918320000411"
            title="Call / Phone"
            className="p-2 rounded-lg text-[#94A3B8] hover:text-[#22D3EE] hover:bg-[#16233B] transition-colors"
          >
            <Phone className="w-4 h-4" />
          </a>
          <a
            href={personalProfile.links.github}
            target="_blank"
            rel="noopener noreferrer"
            title="GitHub Profile"
            className="p-2 rounded-lg text-[#94A3B8] hover:text-[#22D3EE] hover:bg-[#16233B] transition-colors"
          >
            <Github className="w-4 h-4" />
          </a>
          <a
            href={personalProfile.links.linkedin}
            target="_blank"
            rel="noopener noreferrer"
            title="LinkedIn Profile"
            className="p-2 rounded-lg text-[#94A3B8] hover:text-[#22D3EE] hover:bg-[#16233B] transition-colors"
          >
            <Linkedin className="w-4 h-4" />
          </a>
          <a
            href={`mailto:${personalProfile.links.email}`}
            title="Email Direct"
            className="p-2 rounded-lg text-[#94A3B8] hover:text-[#22D3EE] hover:bg-[#16233B] transition-colors"
          >
            <Mail className="w-4 h-4" />
          </a>
          <button
            onClick={onOpenResume}
            className="flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-mono font-medium text-[#22D3EE] hover:bg-[#16233B] transition-colors cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>CV.PDF</span>
          </button>
        </div>

        {/* 4-Card Highlight Metric Strip (Matching video 00:00 & 00:26 bottom of Hero) */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5 w-full">
          {/* Card 1 */}
          <div
            onClick={() => onSelectTab('experience')}
            className="p-4 rounded-xl bg-[#0D1527] border border-[#1E2D4A] hover:border-[#22D3EE]/60 transition-all cursor-pointer text-left group"
          >
            <div className="text-base sm:text-lg font-bold text-white group-hover:text-[#22D3EE] transition-colors">
              BCA Degree
            </div>
            <div className="text-xs font-mono text-[#94A3B8] mt-0.5">
              BKNM University
            </div>
          </div>

          {/* Card 2 */}
          <div
            onClick={() => onSelectTab('experience')}
            className="p-4 rounded-xl bg-[#0D1527] border border-[#1E2D4A] hover:border-[#22D3EE]/60 transition-all cursor-pointer text-left group"
          >
            <div className="text-base sm:text-lg font-bold text-[#22D3EE]">
              8.30 / 10
            </div>
            <div className="text-xs font-mono text-[#94A3B8] mt-0.5">
              1st Ranker Sem 1
            </div>
          </div>

          {/* Card 3 */}
          <div
            onClick={() => onSelectTab('github')}
            className="p-4 rounded-xl bg-[#0D1527] border border-[#1E2D4A] hover:border-[#22D3EE]/60 transition-all cursor-pointer text-left group"
          >
            <div className="text-base sm:text-lg font-bold text-white group-hover:text-[#22D3EE] transition-colors">
              TryHackMe Top 2%
            </div>
            <div className="text-xs font-mono text-[#94A3B8] mt-0.5">
              147+ Completed Labs
            </div>
          </div>

          {/* Card 4 */}
          <div
            onClick={() => onSelectTab('contact')}
            className="p-4 rounded-xl bg-[#0D1527] border border-[#1E2D4A] hover:border-[#22D3EE]/60 transition-all cursor-pointer text-left group"
          >
            <div className="text-base sm:text-lg font-bold text-white group-hover:text-[#22D3EE] transition-colors">
              Veraval
            </div>
            <div className="text-xs font-mono text-[#94A3B8] mt-0.5">
              Gujarat, India
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
