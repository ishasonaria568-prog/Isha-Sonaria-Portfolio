import React, { useState } from 'react';

interface CyberMonogramProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  showGlow?: boolean;
  withBorder?: boolean;
}

const sizeClasses = {
  sm: 'w-8 h-8',
  md: 'w-10 h-10',
  lg: 'w-16 h-16',
  xl: 'w-24 h-24 sm:w-28 sm:h-28',
};

export const CyberMonogram: React.FC<CyberMonogramProps> = ({
  size = 'md',
  className = '',
  showGlow = false,
  withBorder = true,
}) => {
  const [imgError, setImgError] = useState(false);
  const containerSize = sizeClasses[size] || sizeClasses.md;

  return (
    <div className={`relative inline-flex items-center justify-center shrink-0 ${containerSize} ${className}`}>
      {showGlow && (
        <div
          className="absolute inset-0 rounded-full bg-gradient-to-tr from-[#38BDF8]/50 to-[#0EA5E9]/50 blur-md pointer-events-none scale-110"
          aria-hidden="true"
        />
      )}
      <div
        className={`w-full h-full rounded-full overflow-hidden flex items-center justify-center relative z-10 ${
          withBorder ? 'p-[1.5px] bg-gradient-to-tr from-[#38BDF8] via-[#7DD3FC] to-[#0284C7]' : ''
        }`}
      >
        {!imgError ? (
          <img
            src="/logo.png"
            alt="Isha Sonaria Monogram"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover rounded-full bg-[#040814]"
          />
        ) : (
          <svg
            viewBox="0 0 200 200"
            className="w-full h-full bg-[#040814] rounded-full"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <linearGradient id="cyberRingGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#38BDF8" />
                <stop offset="50%" stopColor="#0EA5E9" />
                <stop offset="100%" stopColor="#7DD3FC" />
              </linearGradient>
              <linearGradient id="monogramGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#BAE6FD" />
                <stop offset="50%" stopColor="#38BDF8" />
                <stop offset="100%" stopColor="#0284C7" />
              </linearGradient>
              <filter id="cyberGlow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="3" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>
            <circle cx="100" cy="100" r="96" fill="#040814" />
            <circle cx="100" cy="100" r="88" stroke="url(#cyberRingGrad)" strokeWidth="2.5" filter="url(#cyberGlow)" />
            {/* Left calibration marks */}
            <line x1="8" y1="96" x2="16" y2="96" stroke="#22D3EE" strokeWidth="2" strokeLinecap="round" />
            <line x1="8" y1="100" x2="18" y2="100" stroke="#22D3EE" strokeWidth="2" strokeLinecap="round" />
            <line x1="8" y1="104" x2="16" y2="104" stroke="#22D3EE" strokeWidth="2" strokeLinecap="round" />
            {/* Right calibration marks */}
            <line x1="184" y1="96" x2="192" y2="96" stroke="#22D3EE" strokeWidth="2" strokeLinecap="round" />
            <line x1="182" y1="100" x2="192" y2="100" stroke="#22D3EE" strokeWidth="2" strokeLinecap="round" />
            <line x1="184" y1="104" x2="192" y2="104" stroke="#22D3EE" strokeWidth="2" strokeLinecap="round" />
            {/* Stylized I & S monogram */}
            <path
              d="M74 44 C82 44 88 50 88 58 L88 74 C80 72 72 74 66 80 L62 90 C58 84 56 76 56 68 C56 54 64 44 74 44 Z"
              fill="#38BDF8"
              opacity="0.8"
            />
            <path d="M72 64 L78 68 L70 70 Z" fill="#22D3EE" />
            <path
              d="M80 62 C88 56 102 58 108 66 C114 74 110 84 100 90 L88 98 C80 104 80 114 88 120 C96 126 112 124 120 114 L126 120 C116 134 94 136 82 126 C70 116 70 100 82 92 L94 84 C100 80 102 74 98 68 C94 62 84 62 78 66 Z"
              fill="url(#monogramGrad)"
              filter="url(#cyberGlow)"
            />
            {/* Shield node */}
            <path d="M130 52 L142 46 L154 52 V64 C154 74 142 82 142 82 C142 82 130 74 130 64 Z" stroke="#22D3EE" strokeWidth="2" fill="#121020" />
            <rect x="138" y="60" width="8" height="8" rx="1.5" fill="#22D3EE" />
            <path d="M140 60 V56 C140 54.5 141 53.5 142 53.5 C143 53.5 144 54.5 144 56 V60" stroke="#22D3EE" strokeWidth="1.5" />
            {/* Circuit traces */}
            <path d="M148 68 H166" stroke="#22D3EE" strokeWidth="1.5" strokeLinecap="round" />
            <circle cx="168" cy="68" r="2.5" fill="#22D3EE" />
            <path d="M146 74 H160 L168 80 H174" stroke="#38BDF8" strokeWidth="1.5" strokeLinecap="round" />
            <circle cx="176" cy="80" r="2.5" fill="#38BDF8" />
            <path d="M144 80 H154 L162 86 H170" stroke="#22D3EE" strokeWidth="1.5" strokeLinecap="round" />
            <circle cx="172" cy="86" r="2" fill="#22D3EE" />
            {/* Typography */}
            <text x="100" y="152" textAnchor="middle" fill="#C084FC" fontFamily="monospace" fontWeight="900" fontSize="20" letterSpacing="6">
              ISHA
            </text>
            <text x="100" y="166" textAnchor="middle" fill="#F5F3FF" fontFamily="monospace" fontWeight="700" fontSize="8.5" letterSpacing="3">
              SECURITY LAB
            </text>
            <line x1="72" y1="172" x2="128" y2="172" stroke="url(#cyberRingGrad)" strokeWidth="1" />
          </svg>
        )}
      </div>
    </div>
  );
};
