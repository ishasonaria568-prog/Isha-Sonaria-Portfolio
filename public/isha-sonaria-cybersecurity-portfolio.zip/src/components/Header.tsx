import React, { useState } from 'react';
import { FileText, Terminal, Menu, X, Code, Download } from 'lucide-react';

export type TabId = 'overview' | 'about' | 'stack' | 'projects' | 'github' | 'experience' | 'contact';

interface HeaderProps {
  activeTab: TabId;
  onSelectTab: (tab: TabId) => void;
  onOpenResume: () => void;
  onOpenTerminal?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onSelectTab,
  onOpenResume,
  onOpenTerminal,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks: { label: string; id: TabId; badge?: string }[] = [
    { label: 'Overview', id: 'overview' },
    { label: 'About', id: 'about' },
    { label: 'Stack', id: 'stack' },
    { label: 'Projects', id: 'projects' },
    { label: 'GitHub', id: 'github' },
    { label: 'Experience', id: 'experience' },
    { label: 'Contact', id: 'contact' },
  ];

  return (
    <header
      id="main-navigation"
      className="fixed top-0 left-0 right-0 z-50 bg-[#080D1A]/90 backdrop-blur-xl border-b border-[#1A2642]/80 py-3 transition-all shadow-xl shadow-black/50"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4">
        {/* Brand Logo Lockup */}
        <button
          onClick={() => onSelectTab('overview')}
          className="flex items-center gap-3 group focus:outline-none cursor-pointer text-left shrink-0"
          id="nav-brand-logo"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#1E293B] to-[#0F172A] border border-[#22D3EE]/50 flex items-center justify-center shadow-md shadow-[#22D3EE]/15 group-hover:border-[#22D3EE] transition-all">
            <span className="font-mono font-extrabold text-sm text-[#22D3EE] tracking-tight">IS</span>
          </div>
          <div className="flex flex-col">
            <span className="text-sm sm:text-base font-bold text-white group-hover:text-[#38BDF8] transition-colors leading-tight">
              Isha Sonaria
            </span>
            <span className="text-[11px] font-mono text-[#94A3B8] tracking-wide flex items-center gap-1.5 leading-tight mt-0.5">
              <span>Cybersecurity &amp; SOC Analyst</span>
            </span>
          </div>
        </button>

        {/* Center Nav Pill Capsule */}
        <nav
          className="hidden lg:flex items-center gap-1 px-2 py-1.5 rounded-full bg-[#0D1527] border border-[#1E2D4A] shadow-inner"
          id="desktop-nav-links"
        >
          {navLinks.map((link) => {
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => onSelectTab(link.id)}
                className={`text-xs font-medium tracking-wide px-3.5 py-1.5 rounded-full transition-all cursor-pointer relative ${
                  isActive
                    ? 'bg-gradient-to-r from-[#22D3EE] to-[#38BDF8] text-[#060A12] font-bold shadow-md shadow-[#22D3EE]/30 scale-[1.02]'
                    : 'text-[#94A3B8] hover:text-white hover:bg-[#16233B]'
                }`}
              >
                <span>{link.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Right Controls: Code + Download ZIP + Resume Button */}
        <div className="flex items-center gap-2 sm:gap-2.5 shrink-0" id="nav-actions">
          {/* Direct ZIP Download Button */}
          <a
            href="/isha-sonaria-cybersecurity-portfolio.zip"
            download="isha-sonaria-cybersecurity-portfolio.zip"
            title="Download Complete Portfolio Source Code (.zip)"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-semibold text-[#22D3EE] bg-[#0D1527] border border-[#22D3EE]/40 hover:bg-[#22D3EE]/15 hover:border-[#22D3EE] transition-all cursor-pointer whitespace-nowrap active:scale-95 shadow-sm"
          >
            <Download className="w-3.5 h-3.5 text-[#22D3EE]" />
            <span>ZIP</span>
          </a>

          {/* Quick CLI Code Modal Button */}
          {onOpenTerminal && (
            <button
              onClick={onOpenTerminal}
              title="Launch Cyber Interactive Shell / CLI"
              className="hidden sm:inline-flex items-center justify-center p-2 rounded-lg text-xs font-mono text-[#22D3EE] bg-[#0D1527] border border-[#1E2D4A] hover:border-[#22D3EE] hover:bg-[#16233B] transition-all cursor-pointer"
            >
              <Code className="w-4 h-4" />
            </button>
          )}

          {/* Resume Button */}
          <button
            id="nav-resume-btn"
            onClick={onOpenResume}
            className="inline-flex items-center gap-1.5 px-3.5 sm:px-4 py-1.5 rounded-lg text-xs font-bold text-white bg-gradient-to-r from-[#0284C7] via-[#0EA5E9] to-[#38BDF8] hover:brightness-110 shadow-md shadow-[#0284C7]/40 border border-[#38BDF8]/40 transition-all cursor-pointer whitespace-nowrap active:scale-95"
          >
            <FileText className="w-3.5 h-3.5 text-white" />
            <span className="tracking-wider">RESUME</span>
          </button>

          {/* Mobile drawer toggle */}
          <button
            id="mobile-menu-toggle"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg bg-[#0D1527] border border-[#1E2D4A] text-[#94A3B8] hover:text-white transition-colors focus:outline-none cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-4 h-4 text-[#22D3EE]" /> : <Menu className="w-4 h-4 text-[#22D3EE]" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#080D1A]/98 border-b border-[#1A2642] px-4 pt-3 pb-5 shadow-2xl backdrop-blur-xl animate-view-in">
          <div className="grid grid-cols-2 gap-2 mb-4">
            {navLinks.map((link) => {
              const isActive = activeTab === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => {
                    onSelectTab(link.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`px-3 py-2 rounded-xl text-xs font-sans text-left flex items-center justify-between cursor-pointer ${
                    isActive
                      ? 'bg-gradient-to-r from-[#22D3EE] to-[#38BDF8] text-[#060A12] font-bold shadow-md shadow-[#22D3EE]/20'
                      : 'text-[#94A3B8] hover:text-white bg-[#0D1527] border border-[#1E2D4A]/60'
                  }`}
                >
                  <span>{link.label}</span>
                </button>
              );
            })}
          </div>

          <div className="pt-3 border-t border-[#1E2D4A] flex items-center gap-2">
            <a
              href="/isha-sonaria-cybersecurity-portfolio.zip"
              download="isha-sonaria-cybersecurity-portfolio.zip"
              className="flex-1 py-2 px-3 rounded-lg text-xs font-mono text-[#22D3EE] bg-[#0D1527] border border-[#22D3EE]/40 flex items-center justify-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>DOWNLOAD ZIP</span>
            </a>
            {onOpenTerminal && (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenTerminal();
                }}
                className="py-2 px-3 rounded-lg text-xs font-mono text-white bg-[#0D1527] border border-[#1E2D4A] flex items-center justify-center gap-1.5"
              >
                <Terminal className="w-3.5 h-3.5 text-[#22D3EE]" />
                <span>CLI</span>
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
