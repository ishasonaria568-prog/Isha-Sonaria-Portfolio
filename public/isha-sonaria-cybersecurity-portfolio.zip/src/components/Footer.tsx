import React from 'react';
import { personalProfile } from '../data/portfolioData';
import { TabId } from './Header';
import { ArrowUp, Github, Linkedin, Trophy, Heart } from 'lucide-react';

interface FooterProps {
  onSelectTab?: (tab: TabId) => void;
}

export const Footer: React.FC<FooterProps> = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="border-t border-[#1A2642] bg-[#060A12] py-12 text-center text-xs font-mono text-[#94A3B8]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 flex flex-col items-center gap-4">
        {/* Back to top button (Matching video 00:18) */}
        <button
          onClick={scrollToTop}
          className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#0D1527] border border-[#1E2D4A] hover:border-[#22D3EE] hover:text-white transition-all cursor-pointer shadow-sm text-xs font-medium"
        >
          <ArrowUp className="w-3.5 h-3.5 text-[#22D3EE]" />
          <span>Back to top</span>
        </button>

        {/* Designed & Built with Love */}
        <div className="flex items-center justify-center gap-1.5 text-sm font-sans text-white mt-2">
          <span>Designed &amp; Built with</span>
          <span className="text-[#22D3EE]">💙</span>
          <span>by</span>
          <span className="font-bold text-[#22D3EE]">{personalProfile.displayName}</span>
        </div>

        {/* Social Links */}
        <div className="flex items-center gap-4 text-xs font-mono text-[#94A3B8] my-1">
          <a
            href={personalProfile.links.github}
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-[#22D3EE] transition-colors"
          >
            GitHub
          </a>
          <span>•</span>
          <a
            href={personalProfile.links.linkedin}
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-[#22D3EE] transition-colors"
          >
            LinkedIn
          </a>
          <span>•</span>
          <a
            href={personalProfile.links.tryhackme}
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-[#22D3EE] transition-colors"
          >
            TryHackMe
          </a>
        </div>

        {/* Copyright */}
        <p className="text-[11px] text-[#64748B]">
          &copy; 2026 {personalProfile.displayName}. All rights reserved.
        </p>
      </div>
    </footer>
  );
};
