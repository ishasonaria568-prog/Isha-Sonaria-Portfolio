import React, { useState } from 'react';
import { personalProfile } from '../data/portfolioData';
import { TabId } from './Header';
import {
  Mail,
  Phone,
  MapPin,
  Linkedin,
  Send,
  CheckCircle2,
  Copy,
  Check,
  ShieldCheck,
  ArrowRight,
} from 'lucide-react';

interface ContactSectionProps {
  onSelectTab?: (tab: TabId) => void;
}

export const ContactSection: React.FC<ContactSectionProps> = () => {
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [roleType, setRoleType] = useState('Full-Time Role');
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [senderName, setSenderName] = useState('');
  const [senderEmail, setSenderEmail] = useState('');
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);

  const roleOptions = [
    'Full-Time Role',
    'SOC Analyst L1',
    'Cyber Internship',
    'Consulting / CTF',
  ];

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(personalProfile.links.email);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!senderName || !message) return;
    setSending(true);
    setTimeout(() => {
      setSending(false);
      setFormSubmitted(true);
    }, 1000);
  };

  return (
    <section id="contact" className="py-14 md:py-20 border-t border-[#1A2642] relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Section Tag & Headline (Matching video 00:15) */}
        <div className="flex items-center gap-2 text-xs font-mono text-[#22D3EE] font-semibold mb-3">
          <span>• 05 // GET IN TOUCH</span>
        </div>
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white tracking-tight mb-4">
          Let&apos;s Build Something Together
        </h2>
        <p className="text-sm sm:text-base text-[#94A3B8] leading-relaxed max-w-2xl mb-12 font-sans">
          Have an exciting project, full-time SOC opportunity, entry-level security opening, or collaborative lab challenge? Drop a line and let&apos;s turn complex security requirements into disciplined defensive reality.
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Direct Info Cards (Matching video 00:15-00:17) */}
          <div className="lg:col-span-5 space-y-4 text-left">
            {/* Response Guarantee Card */}
            <div className="p-5 rounded-2xl bg-[#0D1527] border border-[#1E2D4A] shadow-md">
              <span className="text-[10px] font-mono uppercase tracking-wider text-[#22D3EE] font-bold block mb-1">
                RESPONSE GUARANTEE
              </span>
              <p className="text-xs text-[#94A3B8] leading-relaxed">
                I respond to all developer and recruiter inquiries within 24 hours. Available across global time zones for remote roles.
              </p>
            </div>

            {/* Direct Email Card */}
            <div className="p-4 rounded-xl bg-[#0D1527] border border-[#1E2D4A] hover:border-[#22D3EE]/50 transition-all">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#94A3B8]">
                  @ Direct Email
                </span>
                <button
                  onClick={handleCopyEmail}
                  className="text-xs text-[#22D3EE] hover:text-white flex items-center gap-1 cursor-pointer font-mono"
                >
                  {copiedEmail ? (
                    <>
                      <Check className="w-3 h-3 text-[#34D399]" />
                      <span className="text-[#34D399]">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
              <a
                href={`mailto:${personalProfile.links.email}`}
                className="text-sm font-mono font-bold text-white hover:text-[#22D3EE] transition-colors"
              >
                {personalProfile.links.email}
              </a>
            </div>

            {/* Direct Mobile Card */}
            <div className="p-4 rounded-xl bg-[#0D1527] border border-[#1E2D4A] hover:border-[#22D3EE]/50 transition-all">
              <span className="text-[10px] font-mono uppercase tracking-wider text-[#94A3B8] block mb-1">
                Direct Mobile
              </span>
              <div className="text-sm font-mono font-bold text-white">
                +91 93278... (Available on Request)
              </div>
            </div>

            {/* Location Card */}
            <div className="p-4 rounded-xl bg-[#0D1527] border border-[#1E2D4A] hover:border-[#22D3EE]/50 transition-all">
              <span className="text-[10px] font-mono uppercase tracking-wider text-[#94A3B8] block mb-1">
                Location
              </span>
              <div className="text-sm font-bold text-white flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#22D3EE]" />
                <span>Veraval, Gujarat, India</span>
              </div>
            </div>

            {/* LinkedIn Profile Card */}
            <div className="p-4 rounded-xl bg-[#0D1527] border border-[#1E2D4A] hover:border-[#22D3EE]/50 transition-all">
              <span className="text-[10px] font-mono uppercase tracking-wider text-[#94A3B8] block mb-1">
                LinkedIn Profile
              </span>
              <a
                href={personalProfile.links.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm font-mono font-bold text-[#22D3EE] hover:underline"
              >
                linkedin.com/in/isha-sonaria
              </a>
            </div>
          </div>

          {/* Right Column: Interactive Form (Matching video 00:15-00:17) */}
          <div className="lg:col-span-7 p-6 sm:p-8 rounded-2xl bg-[#0D1527] border border-[#1E2D4A] shadow-xl text-left">
            {formSubmitted ? (
              <div className="py-12 text-center">
                <div className="w-14 h-14 rounded-full bg-[#22D3EE]/20 border border-[#22D3EE] text-[#22D3EE] flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Message Dispatched!</h3>
                <p className="text-xs text-[#94A3B8] max-w-sm mx-auto mb-6">
                  Thank you for reaching out. Your inquiry has been transmitted securely and I will get back to you within 24 hours.
                </p>
                <button
                  onClick={() => {
                    setFormSubmitted(false);
                    setMessage('');
                  }}
                  className="px-5 py-2 rounded-xl text-xs font-mono font-semibold text-[#060A12] bg-[#22D3EE] hover:brightness-110 cursor-pointer"
                >
                  Send Another Message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Name */}
                <div>
                  <label className="text-xs font-mono text-[#94A3B8] block mb-1.5">
                    Your Name
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Alex Morgan"
                    value={senderName}
                    onChange={(e) => setSenderName(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-[#080D1A] border border-[#1E2D4A] text-white text-xs font-mono focus:outline-none focus:border-[#22D3EE] transition-colors placeholder:text-[#64748B]"
                  />
                </div>

                {/* Email */}
                <div>
                  <label className="text-xs font-mono text-[#94A3B8] block mb-1.5">
                    Email Address
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="alex@company.com"
                    value={senderEmail}
                    onChange={(e) => setSenderEmail(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-[#080D1A] border border-[#1E2D4A] text-white text-xs font-mono focus:outline-none focus:border-[#22D3EE] transition-colors placeholder:text-[#64748B]"
                  />
                </div>

                {/* Project / Role Type Pills (Matching video 00:16) */}
                <div>
                  <label className="text-xs font-mono text-[#94A3B8] block mb-2">
                    Inquiry Type
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {roleOptions.map((opt) => (
                      <button
                        type="button"
                        key={opt}
                        onClick={() => setRoleType(opt)}
                        className={`py-2 px-2 rounded-xl text-xs font-mono transition-all cursor-pointer text-center ${
                          roleType === opt
                            ? 'bg-gradient-to-r from-[#22D3EE] to-[#38BDF8] text-[#060A12] font-bold shadow-md shadow-[#22D3EE]/25'
                            : 'bg-[#080D1A] border border-[#1E2D4A] text-[#94A3B8] hover:text-white'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Project Details */}
                <div>
                  <label className="text-xs font-mono text-[#94A3B8] block mb-1.5">
                    Message / Opportunity Details
                  </label>
                  <textarea
                    rows={4}
                    required
                    placeholder="Tell me about your team, role requirements, or project goals..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-[#080D1A] border border-[#1E2D4A] text-white text-xs font-mono focus:outline-none focus:border-[#22D3EE] transition-colors placeholder:text-[#64748B] resize-none"
                  />
                </div>

                {/* Send Button */}
                <button
                  type="submit"
                  disabled={sending}
                  className="w-full py-3.5 px-6 rounded-xl text-xs sm:text-sm font-bold text-[#060A12] bg-gradient-to-r from-[#22D3EE] via-[#38BDF8] to-[#0284C7] hover:brightness-110 shadow-lg shadow-[#22D3EE]/30 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-[0.99] font-sans"
                >
                  <Send className="w-4 h-4" />
                  <span>{sending ? 'Transmitting Message...' : 'Send Message'}</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
